#include <stdio.h>
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "driver/gpio.h"

#define LED1_GPIO 4    
#define LED2_GPIO 5
#define LED3_GPIO 6
#define LED4_GPIO 7

#define DELAY_MS 500   


void leds_off() {
    gpio_set_level(LED1_GPIO, 0);
    gpio_set_level(LED2_GPIO, 0);
    gpio_set_level(LED3_GPIO, 0);
    gpio_set_level(LED4_GPIO, 0);
}

void set_leds_state(int l1, int l2, int l3, int l4) {
    gpio_set_level(LED1_GPIO, l1);
    gpio_set_level(LED2_GPIO, l2);
    gpio_set_level(LED3_GPIO, l3);
    gpio_set_level(LED4_GPIO, l4);
}


void fase_binario() {
    for (int i = 0; i < 16; i++) {  
        int b1 = (i >> 0) & 1;
        int b2 = (i >> 1) & 1;
        int b3 = (i >> 2) & 1;
        int b4 = (i >> 3) & 1;
        set_leds_state(b1, b2, b3, b4);
        vTaskDelay(pdMS_TO_TICKS(DELAY_MS));
    }
    leds_off();
}


void fase_varredura() {

    set_leds_state(1,0,0,0); vTaskDelay(pdMS_TO_TICKS(DELAY_MS));
    set_leds_state(0,1,0,0); vTaskDelay(pdMS_TO_TICKS(DELAY_MS));
    set_leds_state(0,0,1,0); vTaskDelay(pdMS_TO_TICKS(DELAY_MS));
    set_leds_state(0,0,0,1); vTaskDelay(pdMS_TO_TICKS(DELAY_MS));

    set_leds_state(0,0,1,0); vTaskDelay(pdMS_TO_TICKS(DELAY_MS));
    set_leds_state(0,1,0,0); vTaskDelay(pdMS_TO_TICKS(DELAY_MS));
    set_leds_state(1,0,0,0); vTaskDelay(pdMS_TO_TICKS(DELAY_MS));
    leds_off();
}


void config_leds() {
    gpio_config_t io_conf = {
        .mode = GPIO_MODE_OUTPUT,
        .intr_type = GPIO_INTR_DISABLE,
        .pin_bit_mask = (1ULL << LED1_GPIO) |
                        (1ULL << LED2_GPIO) |
                        (1ULL << LED3_GPIO) |
                        (1ULL << LED4_GPIO),
        .pull_down_en = 0,
        .pull_up_en = 0
    };
    gpio_config(&io_conf);
    leds_off();
}


void app_main(void) {
    config_leds();
    while (1) {

        fase_binario();
        vTaskDelay(pdMS_TO_TICKS(DELAY_MS*2));

        fase_varredura();
        vTaskDelay(pdMS_TO_TICKS(DELAY_MS*2));
    }
}
